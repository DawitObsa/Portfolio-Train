# Dawit Obsa Knea — Developer Portfolio

A responsive, accessible portfolio for Dawit Obsa Knea, Software Engineer and Full-Stack Developer in Addis Ababa, Ethiopia. Built to meet the Trainlyze Web Development Task 1 requirements.

## Features

- Dark and light themes, with the selected theme saved in browser storage
- Responsive navigation, accessible interaction states, and smooth in-page navigation
- About, categorized skills, internship experience, featured projects, education, and contact sections
- Client-side contact form validation and a message review dialog with a copy-to-clipboard action; this static site does not send or store messages
- Project demo links prefill a contact inquiry
- Responsive layouts for mobile, tablet, and desktop, with reduced-motion support
- No framework, CSS framework, or third-party runtime dependency

## Technologies

Semantic HTML5, CSS3 (Grid, Flexbox, custom properties, media queries), and vanilla JavaScript.

## Project structure

```text
index.html
css/style.css
js/script.js
assets/images/
assets/icons/
documents/
```

A CV PDF and project-specific repository URLs were not provided, so none are fabricated. The Download CV button creates a text CV from the supplied information. GitHub and LinkedIn links use the supplied profiles; add a verified email address and project-specific repository/demo URLs when available.

## Run locally

Open `index.html` in a browser or serve the project directory with any static HTTP server. No package installation or build step is required.

## Deployment

Deploy the project root as a static site on Vercel. No build command is needed; set the output directory to the project root.

**Deployment URL:** _Add your Vercel deployment URL here._

## Screenshots

_Add screenshots after deployment._
