(() => {
  const root = document.documentElement;
  const themeToggle = document.querySelector('.theme-toggle');
  const menuToggle = document.querySelector('.menu-toggle');
  const navLinks = document.querySelector('.nav-links');
  const form = document.querySelector('#contact-form');
  const modal = document.querySelector('#message-modal');
  const modalSummary = document.querySelector('#modal-summary');
  const copyMessageButton = document.querySelector('.email-link');

  let theme = 'dark';
  try {
    const saved = localStorage.getItem('dawit-portfolio-theme');
    theme = saved === 'light' || saved === 'dark' ? saved : 'dark';
  } catch {}
  root.dataset.theme = theme;
  const updateThemeButton = () => {
    const light = root.dataset.theme === 'light';
    themeToggle.setAttribute('aria-label', light ? 'Switch to dark theme' : 'Switch to light theme');
    themeToggle.title = light ? 'Switch to dark theme' : 'Switch to light theme';
  };
  updateThemeButton();
  themeToggle.addEventListener('click', () => {
    root.dataset.theme = root.dataset.theme === 'dark' ? 'light' : 'dark';
    try { localStorage.setItem('dawit-portfolio-theme', root.dataset.theme); } catch {}
    updateThemeButton();
  });

  menuToggle.addEventListener('click', () => {
    const expanded = menuToggle.getAttribute('aria-expanded') === 'true';
    menuToggle.setAttribute('aria-expanded', String(!expanded));
    menuToggle.setAttribute('aria-label', expanded ? 'Open navigation menu' : 'Close navigation menu');
    navLinks.classList.toggle('open', !expanded);
  });
  navLinks.querySelectorAll('a').forEach((link) => link.addEventListener('click', () => {
    navLinks.classList.remove('open');
    menuToggle.setAttribute('aria-expanded', 'false');
    menuToggle.setAttribute('aria-label', 'Open navigation menu');
  }));

  document.querySelectorAll('.demo-link').forEach((link) => link.addEventListener('click', (event) => {
    event.preventDefault();
    document.querySelector('#subject').value = `I'd like to learn more about ${link.dataset.demo}`;
    document.querySelector('#message').focus();
    document.querySelector('#contact').scrollIntoView({ behavior: 'smooth' });
  }));

  const fields = ['name', 'email', 'subject', 'message'];
  const validateField = (field) => {
    const input = document.getElementById(field);
    const error = document.getElementById(`${field}-error`);
    let message = '';
    if (!input.value.trim()) message = 'This field is required.';
    else if (field === 'name' && input.value.trim().length < 2) message = 'Please enter at least 2 characters.';
    else if (field === 'email' && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(input.value.trim())) message = 'Enter a valid email address.';
    else if (field === 'subject' && input.value.trim().length < 3) message = 'Please enter at least 3 characters.';
    else if (field === 'message' && input.value.trim().length < 10) message = 'Please enter at least 10 characters.';
    input.setAttribute('aria-invalid', String(Boolean(message)));
    error.textContent = message;
    return !message;
  };
  fields.forEach((field) => {
    const input = document.getElementById(field);
    input.addEventListener('blur', () => { if (input.value) validateField(field); });
    input.addEventListener('input', () => {
      if (input.getAttribute('aria-invalid') === 'true') validateField(field);
    });
  });

  form.addEventListener('submit', (event) => {
    event.preventDefault();
    const valid = fields.map(validateField).every(Boolean);
    if (!valid) {
      form.querySelector('[aria-invalid="true"]')?.focus();
      return;
    }
    const values = Object.fromEntries(new FormData(form).entries());
    modalSummary.innerHTML = '';
    [['From', values.name], ['Email', values.email], ['Subject', values.subject]].forEach(([label, value]) => {
      const row = document.createElement('div');
      const strong = document.createElement('strong');
      strong.textContent = `${label}: `;
      row.append(strong, document.createTextNode(value));
      modalSummary.append(row);
    });
    const message = document.createElement('div');
    message.className = 'summary-message';
    message.textContent = values.message;
    modalSummary.append(message);
    copyMessageButton.textContent = 'Copy message';
    modal.showModal();
  });

  document.querySelector('.modal-close').addEventListener('click', () => modal.close());
  document.querySelector('.cancel-modal').addEventListener('click', () => modal.close());
  modal.addEventListener('click', (event) => { if (event.target === modal) modal.close(); });
  copyMessageButton.addEventListener('click', async () => {
    const values = Object.fromEntries(new FormData(form).entries());
    const message = `From: ${values.name} (${values.email})\nSubject: ${values.subject}\n\n${values.message}`;
    try {
      await navigator.clipboard.writeText(message);
      copyMessageButton.textContent = 'Message copied';
    } catch {
      copyMessageButton.textContent = 'Copy unavailable — select the message above';
    }
  });

  document.querySelector('#download-cv').addEventListener('click', () => {
    const cv = [
      'DAWIT OBSA KNEA',
      'Software Engineer | Full-Stack Developer',
      'Addis Ababa, Ethiopia',
      'GitHub: https://github.com/DawitObsa',
      'LinkedIn: https://www.linkedin.com/in/dawit-obsa-362453438/',
      '',
      'PROFILE',
      'Software Engineering graduate passionate about full-stack web and mobile application development, problem-solving, teamwork, and emerging technologies.',
      '',
      'EDUCATION',
      'BSc in Software Engineering — Bule Hora University, 2026',
      'CGPA: 3.61 / 4.00',
      '',
      'EXPERIENCE',
      'Software Development Intern — Ministry of Innovation and Technology (MInT), Ethiopia',
      'Four months; contributed to recruitment and employee self-service software, applicant and employee management, and frontend/backend development.',
      '',
      'SELECTED PROJECTS',
      'BHULink — University social networking platform (MERN, Socket.io)',
      'Recruitment and Employee Self-Service Portal (MERN)',
      'Student Document Request Management System (React, Node.js, MongoDB)',
      '',
      'SKILLS',
      'HTML5, CSS3, JavaScript, React.js, Vite, Next.js, Node.js, Express.js, MongoDB, Supabase, React Native, Git, GitHub, Postman, VS Code',
      '',
      'LANGUAGES',
      'Afaan Oromo, Amharic, English',
    ].join('\\n');
    const url = URL.createObjectURL(new Blob([cv], { type: 'text/plain;charset=utf-8' }));
    const link = document.createElement('a');
    link.href = url;
    link.download = 'Dawit_Obsa_Knea_CV.txt';
    link.click();
    URL.revokeObjectURL(url);
  });

  document.querySelector('#year').textContent = new Date().getFullYear();
})();
